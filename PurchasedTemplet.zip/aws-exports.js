// aws-exports.js
const awsconfig = {
    aws_project_region: 'ap-south-1',
    aws_cognito_identity_pool_id: 'your-identity-pool-id',
    aws_cognito_region: 'ap-south-1',
    aws_user_pools_id: 'ap-south-1_lCMCna2RL',
    aws_user_pools_web_client_id: '7mdvqnncbbn2s8m668ip9jus5o',
  }
  
  export default awsconfig
  