const template = "";

export { template };
